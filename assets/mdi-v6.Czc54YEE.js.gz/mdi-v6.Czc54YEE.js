var e=`M21,12L14,5V9C7,10 4,15 3,20C5.5,16.5 9,14.9 14,14.9V19L21,12Z`;export{e as t};
//# sourceMappingURL=mdi-v6.Czc54YEE.js.map